package basset_ftp;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import java.util.Scanner;

public class Basset_FTP {

     private String user;
     private Socket socket = null, socketData = null;
     private boolean DEBUG = true;
     private String host;
     private int port;

     private BufferedWriter writer, writerData;
     private BufferedInputStream readerData;
     private BufferedInputStream reader;
     private String dataIP;
     private int dataPort;

     public Basset_FTP(String ipAddress, int pPort, String pUser) {
          user = pUser;
          port = pPort;
          host = ipAddress;
     }

     public Basset_FTP(String pUser) {
          this("127.0.0.1", 21, pUser);
     }

     public void connect() throws IOException {

          if (socket != null) {
               throw new IOException("La connexion au FTP est déjà activée");
          }

          socket = new Socket(host, port);

          reader = new BufferedInputStream(socket.getInputStream());
          writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

          String response = read();

          if (!response.startsWith("220")) {
               throw new IOException("Erreur de connexion au FTP : \n" + response);
          }
          send("USER " + user);
          response = read();
          if (!response.startsWith("331")) {
               throw new IOException("Erreur de connexion avec le compte utilisateur : \n" + response);
          }

          String passwd = "000000";
          send("PASS " + passwd);
          response = read();
          if (!response.startsWith("230")) {
               throw new IOException("Erreur de connexion avec le compte utilisateur : \n" + response);
          }

     }

     public void quit() {
          try {
               send("QUIT");
          } catch (IOException e) {
               e.printStackTrace();
          } finally {
               if (socket != null) {
                    try {
                         socket.close();
                    } catch (IOException e) {
                         e.printStackTrace();
                    } finally {
                         socket = null;
                    }
               }
          }
     }

     private void enterPassiveMode() throws IOException {

          send("PASV");
          String response = read();
          if (DEBUG) {
               log(response);
          }
          String ip = null;
          int port = -1;

          int debut = response.indexOf('(');
          int fin = response.indexOf(')', debut + 1);
          if (debut > 0) {
               String dataLink = response.substring(debut + 1, fin);
               StringTokenizer tokenizer = new StringTokenizer(dataLink, ",");
               try {

                    ip = tokenizer.nextToken() + "." + tokenizer.nextToken() + "."
                                + tokenizer.nextToken() + "." + tokenizer.nextToken();

                    port = Integer.parseInt(tokenizer.nextToken()) * 256
                                + Integer.parseInt(tokenizer.nextToken());
                    dataIP = ip;
                    dataPort = port;

               } catch (Exception e) {
                    throw new IOException("SimpleFTP received bad data link information: "
                                + response);
               }
          }
     }

     private void createDataSocket() throws UnknownHostException, IOException {
          socketData = new Socket(dataIP, dataPort);
          readerData = new BufferedInputStream(socketData.getInputStream());
          writerData = new BufferedWriter(new OutputStreamWriter(socketData.getOutputStream()));
     }

     public String pwd() throws IOException {
          //On envoie la commande
          send("PWD");
          //On lit la réponse
          return read();
     }

     public String cwd(String dir) throws IOException {
          send("CWD " + dir);
          return read();
     }

     public String list() throws IOException {
          send("TYPE ASCII");
          read();

          enterPassiveMode();
          createDataSocket();
          send("LIST");

          return readData();
     }

     private void send(String command) throws IOException {
          command += "\r\n";
          if (DEBUG) {
               log(command);
          }
          writer.write(command);
          writer.flush();
     }

     private String read() throws IOException {
          String response = "";
          int x;
          byte[] b = new byte[4096];
          x = reader.read(b);
          response = new String(b, 0, x);

          if (DEBUG) {
               log(response);
          }
          return response;
     }

     private String readData() throws IOException {

          String response = "";
          byte[] b = new byte[1024];
          int stream;

          while ((stream = readerData.read(b)) != -1) {
               response += new String(b, 0, stream);
          }

          if (DEBUG) {
               log(response);
          }
          return response;
     }

     public void debugMode(boolean active) {
          DEBUG = active;
     }

     private void log(String str) {
          System.out.println(">> " + str);
     }

     public static void main(String[] args) {

          try {
               Scanner sc = new Scanner(System.in);
               Basset_FTP ftp = new Basset_FTP("A");
               System.out.println("Connexion au FTP");

               ftp.connect();
               ftp.debugMode(true);

               boolean encore = true;
               while (encore) {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Vous êtes maintenant connecté au FTP");
                    System.out.println("Vous avez le droit aux commandes PWD, CWD, LIST et QUIT");
                    System.out.println("-------------------------------------------------------\n\n");
                    String reponse = "";

                    reponse = sc.nextLine().toUpperCase();

                    switch (reponse) {
                         case "PWD":
                              System.out.println(ftp.pwd());
                              break;
                         case "CWD":
                              System.out.println(">> Saisissez le nom du répertoire où vous voulez aller : ");
                              String dir = sc.nextLine();
                              System.out.println(ftp.cwd(dir));
                              break;
                         case "LIST":
                              String list = ftp.list();
                              System.out.println(list);
                              break;
                         case "QUIT":
                              ftp.quit();
                              encore = false;
                              break;
                         default:
                              System.err.println("Commande inconnue !");
                              break;
                    }

               }
          } catch (IOException e) {
               e.printStackTrace();
               System.exit(0);
          }

          System.out.println(" ... ");
     }
}
